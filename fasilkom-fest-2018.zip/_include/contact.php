<div class="container" style="width: 100% !important">
  <div class="row ff-row">
    <div class="col s10 offset-s1 ff-event-tittle left white-text">
      HUBUNGI KAMI
    </div>
  </div>
  <div class="row ff-row event" style="margin-bottom: 0 !important">
    <div class="col s12 ff-contact white-text">
      <div class="col l3 m5 offset-m1 s10 offset-s1 contact-list">
        <a class="fa fa-map-marker white-text logo"></a>
        <h5>Lokasi</h5>
        <p class="desc">UPN "Veteran" Jawa Timur.<br>Surabaya, Indonesia</p>
      </div>
      <div class="col l3 m5 s10 offset-s1 contact-list">
        <a class="fa fa-envelope white-text logo"></a>
        <h5>Email</h5>
        <p class="desc">fasilkomfestupnvjt@gmail.com<br><br></p>
      </div>
      <div class="col l3 m5 offset-m1 s10 offset-s1 contact-list">
        <a class="fa fa-phone white-text logo"></a>
        <h5>Telephone</h5>
        <p class="desc">081252197766 (Nita)<br><br></p>
      </div>
      <div class="col l3 m5 s10 offset-s1 contact-list">
        <a class="fa fa-comment white-text logo"></a>
        <h5>Line</h5>
        <p class="desc">@sso9993h<br><br></p>
      </div>
    </div>
  </div>
</div>
