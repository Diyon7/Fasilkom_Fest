<script src="_controller/baseURL.js"></script>
<script src="_controller/globalFunction.js"></script>
<script src="_controller/globalVariable.js"></script>
<script src="_controller/APIManager.js"></script>
<script src="_controller/globalClass.js"></script>
<script src="api/global.countdown.js"></script>
