<div id="admin-contact" class="modal bottom-sheet white">
  <div class="modal-content">
    <h5 class="grey-text text-darken-2">HUBUNGI ADMIN</h5>
    <p class="grey-text text-darken-2" style="font-size: 16px !important; padding-bottom: 5px;">
      -&nbsp;&nbsp; Hanya melayani saat jam kerja<br>
      -&nbsp;&nbsp; Melayani topik seputar lomba<br>
      -&nbsp;&nbsp; Melayani keluhan website <b>Fasilkom Fest</b><br>
    </p>
    <ul class="collection">
    <li class="collection-item avatar">
      <i class="fa fa-whatsapp circle green darken-2"></i>
      <span class="title">Whatsapp</span>
      <p>081252197766 (Nita) <br>
      </p>
      <a href="#!" class="secondary-content"><i class="fa fa-star"></i></a>
    </li>
    <li class="collection-item avatar">
      <i class="fa fa-comment circle green"></i>
      <span class="title">Line</span>
      <p>@sso9993h <br>
         @idawahyunita
      </p>
      <a href="#!" class="secondary-content"><i class="fa fa-star"></i></a>
    </li>
  </ul>
  </div>
</div>
