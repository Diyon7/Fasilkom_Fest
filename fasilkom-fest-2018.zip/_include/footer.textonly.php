<strong style="font-size: 17px"><p>MADE WITH <i class="fa fa-heart" id="footer-love"></i> BY FF TEAM</p></strong>
