<div class="container">
  <div class="row ff-row">
    <div class="col s12 ff-footer-socmed center noselect">
      <br><br>
      <div class="socmed-list">
        <a class="fa fa-facebook circle blue darken-3" href="https://facebook.com/fasilkom.fest.7" target="_blank"></a>
        <a class="fa fa-instagram circle brown" href="https://www.instagram.com/fasilkomfest/" target="_blank"></a>
        <a class="fa fa-comment circle green accent-4" href="http://line.me/ti/p/%40sso9993h" target="_blank"></a>
      </div>
    </div>
    <div class="col s12 ff-footer center white-text">
      <br>
      <?php
        include("footer.textonly.php");
      ?>
      <br>
    </div>
  </div>
</div>
