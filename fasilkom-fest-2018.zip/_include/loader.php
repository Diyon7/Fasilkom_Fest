<div class="row ff-row loader-body valign-wrapper animated" id="loader-bg">
  <div class="col s12 m6 l4 offset-m3 offset-l4 center">
    <div class="logo" id="loader-logo">
      <img src="img/logo/logo-fasilkomfest0.png">
    </div>
    <br><br>
    <div class="progress center" id="loader-progress">
        <div class="indeterminate lighten-3"></div>
    </div>
  </div>
</div>
