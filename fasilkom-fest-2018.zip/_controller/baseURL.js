var baseUrl = "http://localhost/fasilkom-fest-api-2019/public/";
var baseUrlApi = baseUrl + 'api/funct/';

var baseFrontEnd = 'http://localhost/fasilkom-fest-2019/';
var baseFrontEndAdmin = baseFrontEnd+"admin/";
