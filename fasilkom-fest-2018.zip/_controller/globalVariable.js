// Time setting
var makeIn = new Date('Aug 01, 2018 00:00:00');

// Count setting (hapus jika sudah menggunakan API informasiLomba)
var csoTim = 210;
var csoPeserta = 450;
var fwcTim = 150;
var fwcPeserta = 221;

// Dashboard redirect setting
var dashboard = [];
dashboard[1] = "cso-dashboard";
dashboard[2] = "fwc-dashboard";

var login = [];
login[1] = "cso-login";
login[2] = "fwc-login";

var acara = [];
acara[1] = 'cso';
acara[2] = 'fwc';
acara[3] = 'fpc';
acara[4] = 'fsc';
