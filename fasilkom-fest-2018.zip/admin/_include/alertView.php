<div class="box-body">
  <div class="alert alert-warning alert-dismissible" id="alert-class">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-info"></i> Alert!</h4>
    <div id="alert-content"></div>
  </div>
</div>