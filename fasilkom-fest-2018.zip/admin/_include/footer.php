<!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong><p style="font-size: 17px;">MADE WITH <i class="fa fa-heart" id="footer-love"></i> BY FF TEAM</p></strong>
  </footer>