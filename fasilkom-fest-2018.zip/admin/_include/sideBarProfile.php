<!-- Sidebar user panel (optional) -->
  <div class="user-panel">
    <div class="pull-left image">
      <img src="dist/img/anonymous.jpg" class="img-circle">
    </div>
    <div class="pull-left info">
      <p id="admin-name-side-profile">Anonymous</p>
      <!-- Status -->
      <i class="fa fa-circle text-success"></i> Online
    </div>
  </div>